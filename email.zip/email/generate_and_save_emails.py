import random
import string

def generate_random_email(domain):
    username = ''.join(random.choices(string.ascii_lowercase, k=10))  # Random letters for the username
    return f"{username}@{domain}"

# Number of email addresses to generate
num_addresses = int(input("Enter the number of email addresses to generate: "))

# List of email domains
email_domains = ["gmail.com", "yahoo.com"]

# Open a file for writing
with open("email.txt", "w") as file:
    # Generate and save random email addresses
    for _ in range(num_addresses):
        random_domain = random.choice(email_domains)
        email_address = generate_random_email(random_domain)
        file.write(email_address + "\n")

print(f"{num_addresses} email addresses saved to 'email.txt'")
